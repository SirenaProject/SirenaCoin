Sample configuration files for:
```
systemd: theminerzcoind.service
Upstart: theminerzcoind.conf
OpenRC:  theminerzcoind.openrc
         theminerzcoind.openrcconf
CentOS:  theminerzcoind.init
macOS:   org.theminerzcoin.theminerzcoind.plist
```
have been made available to assist packagers in creating node packages here.

See [doc/init.md](../../doc/init.md) for more information.
